
class PlayvoxException(Exception):
    pass